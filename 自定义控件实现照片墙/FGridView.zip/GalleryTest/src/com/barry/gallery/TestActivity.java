package com.barry.gallery;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;

import com.android.gallerytest.R;
import com.barry.gallery.adapter.MyFGridViewAdapter;
import com.barry.gallery.util.FGridView;
import com.barry.gallery.util.FGridView.FGridViewAdapter;
import com.barry.gallery.util.FGridViewChild;

public class TestActivity extends Activity
{
    FGridView imgList;
    ArrayList<String> paths;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);
        initImageList();
    }
    private void initImageList()
    {
        imgList = (FGridView)findViewById(R.id.my_img_list);
        imgList.setAdapter(getAdapter());
        imgList.setOnItemSelectListener(new FGridView.OnItemSelectListener()
        {
            
            ArrayList<FGridViewChild> list;
            @Override
            public void onShowMultiSelectModel(FGridViewChild curTouchView)
            {
                Log.i("OnItemSelectListener", "onShowMultiSelectModel");
            }
            
            
            @Override
            public void onItemUnSelected(FGridViewChild curTouchView)
            {
                Log.i("OnItemSelectListener", "onItemUnSelected");
                list = imgList.getSelectedChilds();
                if(list != null)
                {
                    Log.i("OnItemSelectListener", "cur selected list size=" + list.size());
                    Log.i("OnItemSelectListener", "��ǰselected list���Ƿ��д�view��" + list.contains(curTouchView));
                }
            }
            
            
            @Override
            public void onItemSelected(FGridViewChild curTouchView)
            {
                Log.i("OnItemSelectListener", "onItemSelected");
                list = imgList.getSelectedChilds();
                if(list != null)
                {
                    Log.i("OnItemSelectListener", "cur selected list size=" + list.size());
                    Log.i("OnItemSelectListener", "��ǰselected list���Ƿ��д�view��" + list.contains(curTouchView));
                }
            }
            
            
            @Override
            public void onItemClick(FGridViewChild curTouchView)
            {
                Log.i("OnItemSelectListener", "onItemClick");
            }
            @Override
            public void onAllItemUnSelected()
            {
                Log.i("OnItemSelectListener", "onAllItemUnSelected");
            }
        });
    }
    @Override
    public void onBackPressed()
    {
        if(imgList != null && imgList.isMultiSelectModel())
        {
            imgList.cancleMultiSelectModel();
        }
        else
        {
            super.onBackPressed();
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        Log.i("onCreateOptionsMenu", "start refresh");
        //����˵�����ˢ�µ�һ�����ˢ�µĹ��ܣ��˹��ܿ���������������ͼƬ
        //���첽ˢ�£�ͼƬ��δ�������ʱ��Ĭ��ͼƬ,���سɹ���ʹ�ô˹���ˢ�¼��ɣ�
        if (paths != null)
        {
            paths.remove(0);
            paths.add(0, "/mnt/sdcard/test2.jpg");
        }
        int[] refreshItemIndexs = new int[]{0};
        imgList.refreshItemsByIndex(refreshItemIndexs);
        return false;
    }
    private FGridViewAdapter getAdapter()
    {
        paths = new ArrayList<String>();
        paths.add("/mnt/sdcard/test.jpg");
        paths.add("/mnt/sdcard/test2.jpg");
        paths.add("/mnt/sdcard/test2.jpg");
        paths.add("/mnt/sdcard/test3.jpg");
        paths.add("/mnt/sdcard/test4.jpg");
        paths.add("/mnt/sdcard/test2.jpg");
        paths.add("/mnt/sdcard/test3.jpg");
        paths.add("/mnt/sdcard/test4.jpg");
        paths.add("/mnt/sdcard/test2.jpg");
        paths.add("/mnt/sdcard/test2.jpg");
        paths.add("/mnt/sdcard/test2.jpg");
        paths.add("/mnt/sdcard/test.jpg");
        paths.add("/mnt/sdcard/test.jpg");
        FGridViewAdapter ga = new MyFGridViewAdapter(this, R.layout.gallery_item, R.id.img, R.id.txt, paths);
        return ga;
    }
}
