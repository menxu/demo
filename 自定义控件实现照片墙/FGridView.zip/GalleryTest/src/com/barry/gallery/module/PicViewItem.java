package com.barry.gallery.module;

public class PicViewItem
{
    /**
     * id
     */
    private String id;
    /**
     * γ��
     */
    private String lat;
    /**
     * ����
     */
    private String lon;
    /**
     * ����ʱ��
     */
    private String createTime;
    /**
     * ����·��
     */
    private String savePath;
    /**
     * λ��
     */
    private String location;
    public String getId()
    {
        return id;
    }
    public void setId(String id)
    {
        this.id = id;
    }
    public String getLat()
    {
        return lat;
    }
    public void setLat(String lat)
    {
        this.lat = lat;
    }
    public String getLon()
    {
        return lon;
    }
    public void setLon(String lon)
    {
        this.lon = lon;
    }
    public String getCreateTime()
    {
        return createTime;
    }
    public void setCreateTime(String createTime)
    {
        this.createTime = createTime;
    }
    public String getSavePath()
    {
        return savePath;
    }
    public void setSavePath(String savePath)
    {
        this.savePath = savePath;
    }
    public String getLocation()
    {
        return location;
    }
    public void setLocation(String location)
    {
        this.location = location;
    }
    
}
