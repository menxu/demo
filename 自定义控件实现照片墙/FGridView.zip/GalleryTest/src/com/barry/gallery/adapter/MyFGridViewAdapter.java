package com.barry.gallery.adapter;

import java.util.ArrayList;

import android.content.Context;

import com.barry.gallery.util.FGridView.FGridViewAdapter;
import com.barry.gallery.util.FGridViewChild;

public class MyFGridViewAdapter extends FGridViewAdapter
{
    public MyFGridViewAdapter(Context context , int itemLayout, int img, int txt, ArrayList<String> paths)
    {
        super(context, itemLayout, img, txt, paths);
    }
    public String getItemTitle(int position)
    {
        return "����";
    }
    @Override
    public void doOtherSettings(FGridViewChild curChild, int position)
    {
        
    }
}
