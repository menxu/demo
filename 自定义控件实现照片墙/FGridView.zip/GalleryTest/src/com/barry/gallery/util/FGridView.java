package com.barry.gallery.util;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Scroller;
import android.widget.TextView;

import com.android.gallerytest.R;
/**
 * 
 * ��    ��: fantao<br>
 * ����: ��������Ƭǽ��ʵ���࣬�̳���ViewGroup�����Ի��������Զ�ѡ�����Ե�ѡ�������첽ˢ�£�Ҳ���Ը�ÿ������ѡ���¼�������
 */
public class FGridView extends ViewGroup implements OnGestureListener
{
    public static abstract class OnItemSelectListener
    {
        public abstract void onShowMultiSelectModel(FGridViewChild curTouchView);
        public abstract void onItemClick(FGridViewChild curTouchView);
        public abstract void onItemSelected(FGridViewChild curTouchView);
        public abstract void onItemUnSelected(FGridViewChild curTouchView);
        public abstract void onAllItemUnSelected();
    }
    public static abstract class FGridViewAdapter
    {
        private Context mContext;
        private ArrayList<String> imgPaths;
        private int mItemLayout;
        private int mImg;
        private int mTxt;
        private int itemImgSize = 150;
        public FGridViewAdapter(Context context , int itemLayout, int imgID, int txtID, ArrayList<String> paths)
        {
            this.mContext = context;
            this.imgPaths = paths;
            this.mItemLayout = itemLayout;
            this.mImg = imgID;
            this.mTxt = txtID;
        }
        /**
         * ����ÿһ���ͼƬ��С
         * @param itemImgSize ͼƬ��С��VIEW��ʼ��ʱͼƬ�Ŀ��߶��ᱻ���óɴ�ֵ��
         */
        public void setItemImgSize(int itemImgSize)
        {
            this.itemImgSize = itemImgSize;
        }
        public int getItemImgSize()
        {
            return itemImgSize;
        }
        int getCount()
        {
            return this.imgPaths.size();
        }
        public ArrayList<String> getImgPaths()
        {
            return imgPaths;
        }
        public void setImgPaths(ArrayList<String> imgPaths)
        {
            this.imgPaths = imgPaths;
        }
        FGridViewChild getView(int position, View convertView, ViewGroup parent)
        {
            long startTime1 = System.currentTimeMillis();
            FGridViewChild gc = null;
            ImageView im = null;
            TextView tv = null;
            if (convertView == null)
            {
                LayoutInflater li = LayoutInflater.from(mContext);
                gc = (FGridViewChild)li.inflate(mItemLayout, null);
            }
            else
            {
                gc = (FGridViewChild)convertView;
            }
            if (gc.getTag() == null)
            {
                ViewHolder vh = new ViewHolder();
                im = (ImageView)gc.findViewById(mImg);
                tv = (TextView)gc.findViewById(mTxt);
                vh.imageView = im;
                vh.txtView = tv;
                gc.setTag(vh);
            }
            else
            {
                ViewHolder vh = (ViewHolder)gc.getTag();
                im = vh.imageView;
                tv = vh.txtView;
            }
            try
            {
                long startTime = System.currentTimeMillis();
                Bitmap bitmap = Util.createBitmap(imgPaths.get(position), itemImgSize, itemImgSize);
                im.setImageBitmap(bitmap);
                System.out.println("setImageBitmap time = " + (System.currentTimeMillis() - startTime));
            }
            catch (FileNotFoundException e)
            {
                e.printStackTrace();
            }
            tv.setText(getItemTitle(position));
            doOtherSettings(gc, position);
            System.out.println("getView time = " + (System.currentTimeMillis() - startTime1));
            return gc;
        }
        class ViewHolder
        {
            protected ImageView imageView;
            protected TextView txtView;
        }
        /**
         * ��ÿһ�����ñ���
         * @param position child��λ��
         * @return ����ֵ��Ϊ����
         */
        public abstract String getItemTitle(int position);
        /**
         * ��һЩ����������
         * @param curChild childView
         * @param position λ��
         */
        public abstract void doOtherSettings(FGridViewChild curChild,int position);
    }
    /**
     * �Ƿ��Ƕ�ѡģʽ
     */
    protected boolean isInMultiSelectModel = false;
    private FGridViewAdapter adapter;
    private int cols = 3;
    private OnItemSelectListener listener;
    private FGridViewChild curTouchChild;
    private ArrayList<FGridViewChild> selectedChilds;
    //����child�߶��ܺ�
    private int allChildHeight;
    private int heightAttr;
    private int widthAttr;
    
    private GestureDetector detector;
    private float mLastMotionY;// ������ĵ�  
    int move = 0;// �ƶ�����  
    int maxMove = 850;// ����������ƶ�����  
    private Scroller mScroller;  
    int up_excess_move = 0;// ���϶��Ƶľ���  
    int down_excess_move = 0;// ���¶��Ƶľ���  
    private final static int TOUCH_STATE_REST = 0;  
    private final static int TOUCH_STATE_SCROLLING = 1;  
    private int mTouchSlop;  
    private int mTouchState = TOUCH_STATE_REST;  
    
	public FGridView(Context context, AttributeSet attrs) {
		super(context, attrs);
		//TypedArray��һ�����������context.obtainStyledAttributes��õ����Ե�����
		//��ʹ����ɺ�һ��Ҫ����recycle����
		//���Ե�������styleable�е�����+��_��+��������
		TypedArray array = context.obtainStyledAttributes(attrs, R.styleable.FGallery);
		heightAttr = array.getDimensionPixelSize(R.styleable.FGallery_abs_height, 0);
		widthAttr = array.getDimensionPixelSize(R.styleable.FGallery_abs_width, 0);
		array.recycle(); //һ��Ҫ���ã�������ε��趨����´ε�ʹ�����Ӱ�� 
		
		mScroller = new Scroller(context);
//        setDescendantFocusability(FOCUS_AFTER_DESCENDANTS);
		mScroller = new Scroller(context);  
        final ViewConfiguration configuration = ViewConfiguration.get(context);  
        // ��ÿ�����Ϊ�ǹ����ľ���  
        mTouchSlop = configuration.getScaledTouchSlop();
        detector = new GestureDetector(this);
	}
	
	@Override
	protected boolean isPaddingOffsetRequired()
	{
	    return true;
	}
	@Override
	public void computeScroll()
	{
	    if (mScroller.computeScrollOffset())
	    {  
            scrollTo(0, mScroller.getCurrY());  
            postInvalidate();  
        } 
	}
	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev)
	{
        final float y = ev.getY();  
        switch (ev.getAction())  
        {  
        case MotionEvent.ACTION_DOWN:  
            System.out.println("###ACTION_DOWN");
  
            mLastMotionY = y;  
            mTouchState = mScroller.isFinished() ? TOUCH_STATE_REST  
                    : TOUCH_STATE_SCROLLING;  
            break;  
        case MotionEvent.ACTION_MOVE:
            System.out.println("###ACTION_MOVE");
            if (FGridViewChild.TOUCH_STATE_PRESS == curTouchChild.getTouchState())
            {
                curTouchChild.setTouchState(FGridViewChild.TOUCH_STATE_NORMAL);
            }
            final int yDiff = (int) Math.abs(y - mLastMotionY);  
            boolean yMoved = yDiff > mTouchSlop;  
            // �ж��Ƿ����ƶ�  
            if (yMoved) {  
                mTouchState = TOUCH_STATE_SCROLLING;  
            }  
            break;  
        case MotionEvent.ACTION_UP:  
            mTouchState = TOUCH_STATE_REST;  
            break;  
        }  
        return mTouchState != TOUCH_STATE_REST;  
	}
	@Override
	public boolean onTouchEvent(MotionEvent ev)
	{
	    final float y = ev.getY();  
        switch (ev.getAction())  
        {  
        case MotionEvent.ACTION_DOWN:  
            if (!mScroller.isFinished()) {  
                mScroller.forceFinished(true);  
                move = mScroller.getFinalY();  
            }  
            mLastMotionY = y;  
            break;  
        case MotionEvent.ACTION_MOVE:  
            if (ev.getPointerCount() == 1) {  
                  
                // ����ָ �϶��Ĵ���  
                int deltaY = 0;  
                deltaY = (int) (mLastMotionY - y);  
                mLastMotionY = y;  
                Log.d("move", "" + move);  
                if (deltaY < 0) {  
                    // ����  
                    // �ж����� �Ƿ񻬹�ͷ  
                    if (up_excess_move == 0) {  
                        if (move > 0) {  
                            int move_this = Math.max(-move, deltaY);  
                            move = move + move_this;  
                            scrollBy(0, move_this);  
                        } else if (move == 0) {// ����Ѿ������ ����������  
                            Log.d("down_excess_move", "" + down_excess_move);  
                            down_excess_move = down_excess_move - deltaY / 2;// ��¼�¶���������ֵ  
                            scrollBy(0, deltaY / 2);  
                        }  
                    } else if (up_excess_move > 0)// ֮ǰ�����ƹ�ͷ  
                    {                     
                        if (up_excess_move >= (-deltaY)) {  
                            up_excess_move = up_excess_move + deltaY;  
                            scrollBy(0, deltaY);  
                        } else {                          
                            up_excess_move = 0;  
                            scrollBy(0, -up_excess_move);                 
                        }  
                    }  
                } else if (deltaY > 0) {  
                    // ����  
                    if (down_excess_move == 0) {  
                        if (maxMove - move > 0) {  
                            int move_this = Math.min(maxMove - move, deltaY);  
                            move = move + move_this;  
                            scrollBy(0, move_this);  
                        } else if (maxMove - move == 0) {  
                            if (up_excess_move <= 100) {  
                                up_excess_move = up_excess_move + deltaY / 2;  
                                scrollBy(0, deltaY / 2);  
                            }  
                        }  
                    } else if (down_excess_move > 0) {  
                        if (down_excess_move >= deltaY) {  
                            down_excess_move = down_excess_move - deltaY;  
                            scrollBy(0, deltaY);  
                        } else {  
                            down_excess_move = 0;  
                            scrollBy(0, down_excess_move);  
                        }  
                    }  
                }         
            }   
            break;  
        case MotionEvent.ACTION_UP:           
            // ����Ǹ��� ��¼��move��  
            if (up_excess_move > 0) {  
                // ����� Ҫ����ȥ  
                scrollBy(0, -up_excess_move);  
                invalidate();  
                up_excess_move = 0;  
            }  
            if (down_excess_move > 0) {  
                // ����� Ҫ����ȥ  
                scrollBy(0, down_excess_move);  
                invalidate();  
                down_excess_move = 0;  
            }  
            mTouchState = TOUCH_STATE_REST;  
            break;  
        }  
        return this.detector.onTouchEvent(ev); 
	}
	@Override
	protected void onLayout(boolean arg0, int arg1, int arg2, int arg3, int arg4) {
	    long startTime = System.currentTimeMillis();
		int hPadding = 5;
	    int childLeft = hPadding;
		int childTop = 0;
		//ˮƽ���
		int hDivider = -1; 
        final int count = getChildCount();
        for (int i = 0; i < count; i++)
        {
            final View child = getChildAt(i);
            if (child.getVisibility() != View.GONE)
            {
                final int childWidth = child.getMeasuredWidth();
                //��һ��ѭ������ˮƽ���
                if (i == 0)
                {
                    hDivider = (getWidth() - (childWidth * cols) - (2* hPadding))/(cols + 1);
                }
                //ˮƽ�����СΪ3
                hDivider = Math.max(hDivider,3);
                final int childHeight = child.getMeasuredHeight();
                childLeft += hDivider;
                child.layout(childLeft, childTop, childLeft + childWidth, childTop + childHeight);
                //������һ��child����ʼλ��
                int hOffset = (i+1) % cols;
                childLeft = hOffset * (childWidth+hDivider) + hPadding;
            	
            	int vOffset = (i+1)/cols;
            	childTop = vOffset * (childHeight+5);
            	if(child instanceof FGridViewChild)
            	{
            	    final GestureDetector gd = new GestureDetector(new MyGestureListener((FGridViewChild)child,this));
            	    child.setOnTouchListener(new OnTouchListener()
            	    {
            	        
            	        @Override
            	        public boolean onTouch(View v, MotionEvent event)
            	        {
            	            return gd.onTouchEvent(event);
            	        }
            	    });
            	}else{
            	    
            	    Log.e("ImageList", "adapter.getView() must return a GalleryChild");
            	}
            }
        }
        System.out.println("onlayout time = " + (System.currentTimeMillis() - startTime));
	}
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
	    long startTime = System.currentTimeMillis();
		final int count = getChildCount();
        for (int i = 0; i < count; i++)
        {
        	final View child = getChildAt(i);
        	child.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED);
        	allChildHeight += child.getHeight();
        }
        maxMove = (int)(allChildHeight * 0.75);
        System.out.println("##########maxMove = " + maxMove);
        int w = widthAttr == 0 ? widthMeasureSpec : widthAttr|MeasureSpec.EXACTLY;
        int h = heightAttr == 0 ? heightMeasureSpec : heightAttr|MeasureSpec.EXACTLY;
        super.onMeasure(w, h);
        System.out.println("onMeasure time = " + (System.currentTimeMillis() - startTime));
	}
	public void setOnItemSelectListener(OnItemSelectListener listener)
	{
	    this.listener = listener;
	}
	public OnItemSelectListener getOnItemSelectListener()
	{
	    return this.listener;
	}
	public FGridViewAdapter getAdapter()
    {
        return adapter;
    }
	public void setAdapter(FGridViewAdapter adapter)
    {
	    long startTime = System.currentTimeMillis();
        this.adapter = adapter;
        int count = adapter.getCount();
        for (int i = 0;i < count;i++)
        {
            View childView = getChildAt(i);
            if (childView == null)
            {
                FGridViewChild gc = adapter.getView(i, null, this);
                this.addView(gc);
            }
            else
            {
                adapter.getView(i, childView, this);
//                invalidate();
            }
            //TODO �ʵ�����childview������������һ������ʱ��Ҫ����һ����
        }
        System.out.println("setAdapter time = " + (System.currentTimeMillis() - startTime));
    }
	/**
	 * ˢ�½���
	 */
	public void refreshAllItems()
	{
	    if(this.adapter == null)
	    {
	        return;
	    }
	    setAdapter(this.adapter);
//	    invalidate();
	}
	public void refreshItemsByIndex(int[] refreshItemIndexs)
	{
	    long startTime = System.currentTimeMillis();
	    if (this.adapter == null || refreshItemIndexs == null || refreshItemIndexs.length == 0)
	    {
	        return;
	    }
	    int count = refreshItemIndexs.length;
        for (int i = 0;i < count;i++)
        {
            View childView = getChildAt(refreshItemIndexs[i]);
            if (childView == null)
            {
                return;
            }
            else
            {
                adapter.getView(refreshItemIndexs[i], childView, this);
            }
        }
        System.out.println("refreshItemsByIndex time = " + (System.currentTimeMillis() - startTime));
	}
	void setCurTouchChild(FGridViewChild curTouchChild)
    {
        this.curTouchChild = curTouchChild;
    }
	void addSelectedChild(FGridViewChild child)
	{
	    if (this.selectedChilds == null)
	    {
	        this.selectedChilds = new ArrayList<FGridViewChild>();
	    }
	    this.selectedChilds.add(child);
	}
	void removeSelectedChild(FGridViewChild child)
	{
	    if (this.selectedChilds != null)
	    {
	        this.selectedChilds.remove(child);
	    }
	}
	public ArrayList<FGridViewChild> getSelectedChilds()
    {
	    if (selectedChilds == null)
	    {
	        return null;
	    }
        return (ArrayList<FGridViewChild>)selectedChilds.clone();
    }
	@Override
	public void addView(View child)
	{
	    if(child instanceof FGridViewChild)
	    {
	        super.addView(child);
	    }else{
	        throw new IllegalArgumentException("the child must be instance of GalleryChild");
	    }
	}
	/**
	 * �˳���ѡģʽ
	 */
	public void cancleMultiSelectModel()
	{
	    this.isInMultiSelectModel = false;
	    for(int i=0;i<getChildCount();i++)
	    {
	        View child = getChildAt(i);
	        if(child instanceof FGridViewChild)
	        {
	            ((FGridViewChild)child).setTouchState(FGridViewChild.TOUCH_STATE_NORMAL);
	        }
	    }
	    if(this.selectedChilds != null)
	    {
	        this.selectedChilds.clear();
	    }
	    this.selectedChilds.clear();
	    listener.onAllItemUnSelected();
	}
	public boolean isMultiSelectModel()
	{
	    return this.isInMultiSelectModel;
	}

    @Override
    public boolean onDown(MotionEvent e)
    {
        //�˴�Ҫreturn true�����򣬴����հ״���������Ч��
        return true;
    }

    @Override
    public void onShowPress(MotionEvent e)
    {
        
    }

    @Override
    public boolean onSingleTapUp(MotionEvent e)
    {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX,
            float distanceY)
    {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e)
    {
        
    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
            float velocityY)
    {
        //����ָ ���ٲ����Ĵ���  
        Log.d("onFling", "onFling");  
        if (up_excess_move == 0 && down_excess_move == 0) {  
  
            int slow = -(int) velocityY * 3 / 4;  
            mScroller.fling(0, move, 0, slow, 0, 0, 0, maxMove);  
            move = mScroller.getFinalY();  
            computeScroll();  
        }  
        return false;  
    }
}
class MyGestureListener implements OnGestureListener
{
    private FGridViewChild curView;
    private FGridView fGridView;
    public MyGestureListener(FGridViewChild cView, FGridView imgList)
    {
        this.curView = cView;
        this.fGridView = imgList;
    }
    @Override  
    public boolean onDown(MotionEvent e) {  
        Log.d("TAG","[+++++++++++][onDown]");
        if(!fGridView.isInMultiSelectModel)
        {
            curView.setTouchState(FGridViewChild.TOUCH_STATE_PRESS);
        }
        fGridView.setCurTouchChild(curView);
        return true;  
    }
    
    @Override  
 // �û����´������������ƶ����ɿ�����1��MotionEvent ACTION_DOWN,   
  //���ACTION_MOVE, 1��ACTION_UP����  
  // e1����1��ACTION_DOWN MotionEvent  
  // e2�����һ��ACTION_MOVE MotionEvent  
  // velocityX��X���ϵ��ƶ��ٶȣ�����/��  
  // velocityY��Y���ϵ��ƶ��ٶȣ�����/��  
  // �������� ��  
  // X�������λ�ƴ���FLING_MIN_DISTANCE�����ƶ��ٶȴ���FLING_MIN_VELOCITY������/��  
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,  
            float velocityY) { 
        curView.setTouchState(FGridViewChild.TOUCH_STATE_NORMAL);
        return true;  
    }  

    @Override  
    public void onLongPress(MotionEvent e) {  
        Log.d("TAG","[+++++++++++][onLongPress]");
        if(!fGridView.isInMultiSelectModel)
        {
            fGridView.getOnItemSelectListener().onShowMultiSelectModel(curView);
            fGridView.addSelectedChild(curView);
            fGridView.getOnItemSelectListener().onItemSelected(curView);
            curView.setTouchState(FGridViewChild.TOUCH_STATE_SELECT);
            fGridView.isInMultiSelectModel = true;
        }
        else
        {
            //ģʽ�л�
            if(curView.getTouchState() == FGridViewChild.TOUCH_STATE_NORMAL)
            {
                curView.setTouchState(FGridViewChild.TOUCH_STATE_SELECT);
                fGridView.addSelectedChild(curView);
                fGridView.getOnItemSelectListener().onItemSelected(curView);
            }
            else
            {
                curView.setTouchState(FGridViewChild.TOUCH_STATE_NORMAL);
                fGridView.removeSelectedChild(curView);
                fGridView.getOnItemSelectListener().onItemUnSelected(curView);
            }
        }
            
    }  

    @Override  
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX,  
            float distanceY) {
        Log.d("TAG","[+++++++++++][onScroll]");
        if (!fGridView.isInMultiSelectModel)
        {
            curView.setTouchState(FGridViewChild.TOUCH_STATE_NORMAL);
        }
        return true;  
    }  
    
    @Override  
    public void onShowPress(MotionEvent e) {  
        Log.d("TAG","[+++++++++++][onShowPress]");
        if(!fGridView.isInMultiSelectModel)
        {
            curView.setTouchState(FGridViewChild.TOUCH_STATE_PRESS);
        }
    }  

    @Override  
    public boolean onSingleTapUp(MotionEvent e) {  
        Log.d("TAG","[+++++++++++][onSingleTapUp]");
        if(fGridView.isInMultiSelectModel)
        {
            if(curView.getTouchState() == FGridViewChild.TOUCH_STATE_NORMAL)
            {
                curView.setTouchState(FGridViewChild.TOUCH_STATE_SELECT);
                fGridView.addSelectedChild(curView);
                fGridView.getOnItemSelectListener().onItemSelected(curView);
            }
            else
            {
                curView.setTouchState(FGridViewChild.TOUCH_STATE_NORMAL);
                fGridView.removeSelectedChild(curView);
                fGridView.getOnItemSelectListener().onItemUnSelected(curView);
            }
        }
        else
        {
            curView.setTouchState(FGridViewChild.TOUCH_STATE_NORMAL);
            fGridView.getOnItemSelectListener().onItemClick(curView);
        }
        return true;  
    }
}