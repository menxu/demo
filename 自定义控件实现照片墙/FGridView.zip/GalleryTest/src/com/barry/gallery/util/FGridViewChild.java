package com.barry.gallery.util;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.widget.LinearLayout;

public class FGridViewChild extends LinearLayout
{
    public static final int TOUCH_STATE_NORMAL = 0;
    public static final int TOUCH_STATE_PRESS = 1;
    public static final int TOUCH_STATE_SELECT = 2;
    private int touchState = TOUCH_STATE_NORMAL;
    public FGridViewChild(Context context, AttributeSet attrs)
    {
        super(context, attrs);
        setWillNotDraw(false);
    }
    public FGridViewChild(Context context)
    {
        super(context);
        setOrientation(LinearLayout.VERTICAL);
        setWillNotDraw(false);
    }
    @Override
    public void draw(Canvas canvas)
    {
        super.draw(canvas);
        Paint p = new Paint();
        switch (touchState)
        {
            case TOUCH_STATE_PRESS:
                p.setARGB(125, 245, 146, 10);
//                int mColorYELLOW = (int) Math.floor(Color.YELLOW);
//                img.setColorFilter(mColorYELLOW, PorterDuff.Mode.MULTIPLY);
                canvas.drawPaint(p);
                break;
            case TOUCH_STATE_SELECT:
                //ͼƬ��͸������
                p.setARGB(125, 0, 0, 0);
                canvas.drawPaint(p);
                
                //�����Ͻ�������
                RectF rect = new RectF(getWidth()-25, 0, getWidth(), 25);
                p.setARGB(255, 245, 146, 10);
                p.setStyle(Style.FILL);
                canvas.drawRect(rect, p);
                
                //���������ڵĶԹ�
                Path path = new Path();
                path.moveTo(getWidth()-23, 15);
                path.lineTo(getWidth()-15, 22);
                path.lineTo(getWidth()-2, 5);
                p.setARGB(255, 255, 255, 255);
                p.setStyle(Style.STROKE);
                p.setAntiAlias(true);
                //��ϸΪ3
                p.setStrokeWidth(3);
                canvas.drawPath(path, p);
                
                break;
            default:
                break;
        }
    }
    public void setTouchState(int state)
    {
        if(touchState == state)
        {
            return;
        }
        touchState = state;
        invalidate();
    }
    public int getTouchState()
    {
        return touchState;
    }
}
